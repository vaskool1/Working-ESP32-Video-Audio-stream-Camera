#include <driver/i2s.h>
#include <WebServer.h>

//---- I2S Configuration (INMP441) ------------
#define I2S_SCK           14 
#define I2S_WS            15 
#define I2S_SD            12
#define I2S_PORT          I2S_NUM_1

//---- Sampling ------------
#define SAMPLE_RATE       22050 
#define SAMPLE_BITS       32    // Mic hardware is 32-bit
#define DMA_BUF_COUNT     2
#define DMA_BUF_LEN       1024

WebServer Audioserver(82);
WebServer VideoAudioserver(86);

const int sampleRate = SAMPLE_RATE; 
const int numChannels = 1; 
const int bufferSize = DMA_BUF_LEN; 

struct WAVHeader {
  char chunkId[4];          
  uint32_t chunkSize;       
  char format[4];           
  char subchunk1Id[4];      
  uint32_t subchunk1Size;   
  uint16_t audioFormat;     
  uint16_t numChannels;     
  uint32_t sampleRate;      
  uint32_t byteRate;        
  uint16_t blockAlign;      
  uint16_t bitsPerSample;   
  char subchunk2Id[4];      
  uint32_t subchunk2Size;   
};

void initializeWAVHeader(WAVHeader &header, uint32_t sampleRate, uint16_t bitsPerSample, uint16_t numChannels) {
  strncpy(header.chunkId, "RIFF", 4);
  strncpy(header.format, "WAVE", 4);
  strncpy(header.subchunk1Id, "fmt ", 4);
  strncpy(header.subchunk2Id, "data", 4);
  header.chunkSize = 0; 
  header.subchunk1Size = 16; 
  header.audioFormat = 1; 
  header.numChannels = numChannels;
  header.sampleRate = sampleRate;
  header.bitsPerSample = bitsPerSample;
  header.byteRate = (sampleRate * bitsPerSample * numChannels) / 8;
  header.blockAlign = (bitsPerSample * numChannels) / 8;
  header.subchunk2Size = 0; 
}

void mic_i2s_init() {
  i2s_config_t i2sConfig = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX), 
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = i2s_bits_per_sample_t(SAMPLE_BITS),
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT, 
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = 0,
    .dma_buf_count = DMA_BUF_COUNT,
    .dma_buf_len = DMA_BUF_LEN,
    .use_apll = false // APLL often conflicts with the Camera XCLK on ESP32-CAM!
  };
  i2s_driver_install(I2S_PORT, &i2sConfig, 0, NULL);
  i2s_pin_config_t pinConfig = {
    .bck_io_num = I2S_SCK, 
    .ws_io_num = I2S_WS ,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = I2S_SD 
  };
  i2s_set_pin(I2S_PORT, &pinConfig);
}

void handleAudioStream() {
  WAVHeader wavHeader;
  // Browser only likes 16-bit live streams!
  initializeWAVHeader(wavHeader, sampleRate, 16, numChannels);
  WiFiClient Audioclient = Audioserver.client();
  Audioclient.print("HTTP/1.1 200 OK\r\n");
  Audioclient.print("Content-Type: audio/wav\r\n");
  Audioclient.print("Cache-Control: no-cache\r\n");
  Audioclient.print("Access-Control-Allow-Origin: *\r\n\r\n");
  Audioclient.write(reinterpret_cast<const uint8_t*>(&wavHeader), sizeof(wavHeader));

  uint8_t buffer[bufferSize];
  int16_t outBuffer[bufferSize / 2]; 
  size_t bytesRead = 0;
  int silenceCount = 0;

  while (true) {
    if (!Audioclient.connected()) break;
    i2s_read(I2S_PORT, buffer, bufferSize, &bytesRead, portMAX_DELAY);
    if (bytesRead > 0) {
      int samplesRead = bytesRead / 4; 
      int32_t *raw32 = (int32_t *)buffer;
      bool hasAudio = false;
      
      int16_t peakVolume = 0;
      
      for (int i = 0; i < samplesRead; i++) {
         int32_t sample = raw32[i];
         
         sample = sample >> 12; // 16x volume gain safely clamped
         
         if (sample > 32767) sample = 32767;
         if (sample < -32768) sample = -32768;
         
         int16_t finalSample = (int16_t)sample;
         outBuffer[i] = finalSample;
         
         if (abs(finalSample) > peakVolume) {
            peakVolume = abs(finalSample);
         }
      }
      
      if (peakVolume == 0) {
         silenceCount++;
         if (silenceCount % 50 == 1) { 
            Serial.println("WARNING: The microphone is capturing pure silence (Volume: 0).");
         }
      } else {
         if (silenceCount > 0) {
            Serial.print("SUCCESS: Audio detected! Peak Volume (0-32768): ");
            Serial.println(peakVolume);
         }
         silenceCount = 0; 
      }
      
      Audioclient.write((const uint8_t*)outBuffer, samplesRead * 2);
    }
  }
}

void audio_http_stream() {
  mic_i2s_init(); // Initialize I2S hardware exactly once here
  Audioserver.on("/audio", HTTP_GET, handleAudioStream);
  Audioserver.begin();
}

// Reference to the PIR state tracked in the main INO file
extern bool motionDetected;

void handleMotionStatus() {
  if (motionDetected) {
    VideoAudioserver.send(200, "text/plain", "1");
  } else {
    VideoAudioserver.send(200, "text/plain", "0");
  }
}

const char* index_html = R"=====(
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart Doorbell</title>
  <style>
    body { background: #111; color: #fff; font-family: sans-serif; text-align: center; margin: 0; padding: 20px; }
    .box { display: flex; flex-direction: column; align-items: center; gap: 15px; }
    img { border: 2px solid #444; border-radius: 8px; width: 100%; max-width: 640px; height: auto; background: #000; min-height: 240px; }
    .rec-btn, .play-btn { background: #ff0000; color: #fff; border: none; padding: 15px 40px; font-size: 18px; border-radius: 30px; cursor: pointer; font-weight: bold; width: 100%; max-width: 640px; transition: background 0.3s; }
    .play-btn { background: #0088ff; }
    .play-btn:hover { background: #0066cc; }
    .rec-btn.active { background: #555; animation: blink 1s infinite; }
    #motionAlert { display: none; background: #ff0000; color: #fff; padding: 15px; border-radius: 8px; font-weight: bold; font-size: 20px; width: 100%; max-width: 640px; box-sizing: border-box; animation: blink 1s infinite; margin-bottom: 10px;}
    @keyframes blink { 50% { opacity: 0.6; } }
  </style>
</head>
<body>
  <h2>Doorbell Live Stream</h2>
  <div class="box">
    <div id="motionAlert">🚨 MOTION DETECTED AT DOOR! 🚨</div>
    <img id="vStream" src="" crossorigin="anonymous" alt="Video Stream Loading...">
    <button id="playBtn" class="play-btn">🔊 Connect Audio Stream</button>
    <button id="recBtn" class="rec-btn" style="display:none;">🔴 RECORD CLIP</button>
  </div>
  <script>
    const ip = window.location.hostname;
    document.getElementById('vStream').src = "http://" + ip + ":81/stream";
    
    let audioCtx, audioDest, mediaRecorder;
    let chunks = [];
    let recording = false;
    let autoRecordTimeout = null;
    let autoRecordPending = false;
    
    // Check for motion every 1 second
    setInterval(async () => {
      try {
        const res = await fetch("http://" + ip + ":86/motion");
        const text = await res.text();
        if (text === "1") {
          document.getElementById('motionAlert').style.display = 'block';
          
          // Forcefully connect the audio if it isn't already running
          if (!audioDest) {
             document.getElementById('playBtn').click();
          }
          
          // Auto-record if not already recording
          if (!recording && !autoRecordPending) {
             autoRecordPending = true;
             startRecording();
             autoRecordTimeout = setTimeout(() => {
                if (recording) stopRecording();
                autoRecordPending = false;
             }, 60000); // 1 Minute
          }
        } else {
          document.getElementById('motionAlert').style.display = 'none';
        }
      } catch(e) {}
    }, 1000);
    
    document.getElementById('playBtn').onclick = async () => {
      document.getElementById('playBtn').innerText = "Connecting...";
      
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      audioDest = audioCtx.createMediaStreamDestination();
      
      try {
        const response = await fetch("http://" + ip + ":82/audio?t=" + new Date().getTime());
        const reader = response.body.getReader();
        
        document.getElementById('playBtn').style.display = 'none';
        document.getElementById('recBtn').style.display = 'block';
        
        let nextTime = audioCtx.currentTime;
        let headerSkipped = false;
        
        const processChunk = async () => {
          const { done, value } = await reader.read();
          if (done) return;
          if (audioCtx.state === 'suspended') await audioCtx.resume();
          
          try {
            let data = new Uint8Array(value.buffer);
            if (!headerSkipped) {
              if (data.length > 44) { data = data.slice(44); headerSkipped = true; } 
              else { processChunk(); return; }
            }
            if (data.length % 2 !== 0) data = data.slice(0, data.length - 1);
            
            const int16Array = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
            const float32Array = new Float32Array(int16Array.length);
            for (let i = 0; i < int16Array.length; i++) float32Array[i] = int16Array[i] / 32768.0;
            
            const audioBuffer = audioCtx.createBuffer(1, float32Array.length, 22050);
            audioBuffer.getChannelData(0).set(float32Array);
            
            const source = audioCtx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioCtx.destination); 
            source.connect(audioDest);            
            
            nextTime = Math.max(audioCtx.currentTime, nextTime);
            source.start(nextTime);
            nextTime += audioBuffer.duration;
          } catch(e) { } 
          processChunk();
        };
        processChunk();
      } catch(err) {
        alert("Audio connection failed.");
      }
    };

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 640; canvas.height = 480;

    function loop() {
      if (recording) { 
        ctx.drawImage(document.getElementById('vStream'), 0, 0, canvas.width, canvas.height); 
        requestAnimationFrame(loop); 
      }
    }
    
    function startRecording() {
        recording = true; loop();
        const vS = canvas.captureStream(20);
        let tracks = [...vS.getTracks()];
        if (audioDest) tracks.push(...audioDest.stream.getTracks()); // Safely add audio if connected
        
        const combined = new MediaStream(tracks);
        mediaRecorder = new MediaRecorder(combined, { mimeType: 'video/webm' });
        chunks = [];
        mediaRecorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
        mediaRecorder.onstop = () => {
          const blob = new Blob(chunks, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a'); a.href = url; a.download = 'doorbell_motion_event.webm'; a.click();
          URL.revokeObjectURL(url);
        };
        mediaRecorder.start(100);
        
        const recBtn = document.getElementById('recBtn');
        recBtn.classList.add('active'); 
        recBtn.innerText = '⏹ STOP & SAVE';
        recBtn.style.display = 'block'; // Ensure it's visible even if audio isn't connected yet
    }
    
    function stopRecording() {
        recording = false; 
        mediaRecorder.stop();
        const recBtn = document.getElementById('recBtn');
        recBtn.classList.remove('active'); 
        recBtn.innerText = '🔴 RECORD CLIP';
        if (autoRecordTimeout) clearTimeout(autoRecordTimeout);
    }

    document.getElementById('recBtn').onclick = () => {
      if (recording) {
        stopRecording();
      } else {
        startRecording();
      }
    };
  </script>
</body>
</html>
)=====";

void handleVideAudio(){
  VideoAudioserver.send(200, "text/html", index_html);
}

void VideoAudio_http(){
  VideoAudioserver.on("/", HTTP_GET, handleVideAudio);
  VideoAudioserver.on("/motion", HTTP_GET, handleMotionStatus);
  VideoAudioserver.begin();
}
