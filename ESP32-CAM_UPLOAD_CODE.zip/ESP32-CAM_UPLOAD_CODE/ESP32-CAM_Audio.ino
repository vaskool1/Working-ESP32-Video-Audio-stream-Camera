#include "esp_camera.h"
#include <WiFi.h>
#include <SPIFFS.h>
#include "audio_server.h"

#define CAMERA_MODEL_AI_THINKER // Has PSRAM
#include "camera_pins.h"

// ===========================
// WiFi Credentials & Pins
// ===========================
const char* ssid = "Derek's A16";
const char* password = "WEWEWEW8";

const char* ap_ssid = "ESP32-Doorbell";
const char* ap_password = "password123";
IPAddress apIP(192, 168, 4, 1);
IPAddress gateway(192, 168, 4, 1);
IPAddress subnet(255, 255, 255, 0);

#define PIR_PIN 13
#define FLASH_LED 4      // The big bright white LED
#define INDICATOR_LED 33 // The tiny red LED on the back

// PIR state tracking
bool motionDetected = false;
unsigned long lastMotionTime = 0;
#define MOTION_COOLDOWN_MS 3000  // Minimum ms between motion alerts

// Function declarations from your custom files
void startCameraServer();
void setupLedFlash(int pin);
void audio_http_stream();
void VideoAudio_http();

void setup() {
  // 1. IMMEDIATELY turn on both LEDs to prove the board is receiving power
  pinMode(FLASH_LED, OUTPUT);
  pinMode(INDICATOR_LED, OUTPUT);
  digitalWrite(FLASH_LED, HIGH);   // Turns ON bright white flash
  digitalWrite(INDICATOR_LED, LOW); // Turns ON tiny red LED

  Serial.begin(115200);
  Serial.setDebugOutput(true);
  delay(1000); // Give serial monitor time to catch up

  Serial.println("\n\n===================================");
  Serial.println("[START] Smart Doorbell Powering Up...");
  Serial.println("===================================");

  // Set up PIR sensor (INPUT_PULLDOWN keeps pin LOW when sensor is idle)
  pinMode(PIR_PIN, INPUT_PULLDOWN);

  // ===========================
  // CAMERA CONFIGURATION
  // ===========================
  Serial.println("[STEP 1] Loading Camera Configuration...");
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.frame_size = FRAMESIZE_UXGA;
  config.pixel_format = PIXFORMAT_JPEG;
  config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location = CAMERA_FB_IN_PSRAM;
  config.jpeg_quality = 10;
  config.fb_count = 2;
  
  if(config.pixel_format == PIXFORMAT_JPEG){
    if(psramFound()){
      config.jpeg_quality = 10;
      config.fb_count = 2;
      config.grab_mode = CAMERA_GRAB_LATEST;
    } else {
      config.frame_size = FRAMESIZE_SVGA;
      config.fb_location = CAMERA_FB_IN_DRAM;
    }
  } else {
    config.frame_size = FRAMESIZE_240X240;
#if CONFIG_IDF_TARGET_ESP32S3
    config.fb_count = 2;
#endif
  }

#if defined(CAMERA_MODEL_ESP_EYE)
  pinMode(13, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
#endif

  // --- CRITICAL POWER TEST 1: CAMERA ---
  Serial.println("[STEP 2] Initializing Camera Hardware...");
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("!!! CAMERA INIT FAILED !!! Error 0x%x\n", err);
    return;
  }
  
  sensor_t * s = esp_camera_sensor_get();
  if (s->id.PID == OV3660_PID) {
    s->set_vflip(s, 1); 
    s->set_brightness(s, 1); 
    s->set_saturation(s, -2); 
  }
  if(config.pixel_format == PIXFORMAT_JPEG){
    s->set_framesize(s, FRAMESIZE_VGA);
  }

#if defined(CAMERA_MODEL_M5STACK_WIDE) || defined(CAMERA_MODEL_M5STACK_ESP32CAM)
  s->set_vflip(s, 1);
  s->set_hmirror(s, 1);
#endif

#if defined(CAMERA_MODEL_ESP32S3_EYE)
  s->set_vflip(s, 1);
#endif

#if defined(LED_GPIO_NUM)
  setupLedFlash(LED_GPIO_NUM);
#endif

  // --- CRITICAL POWER TEST 2: WIFI & SPIFFS ---
  Serial.println("[STEP 3] Initializing SPIFFS and Access Point...");
  
  if (!SPIFFS.begin(true)) {
    Serial.println("An Error has occurred while mounting SPIFFS");
  } else {
    Serial.println("SPIFFS mounted successfully");
  }

  // Use Access Point mode ONLY (no connecting to home hotspot)
  WiFi.mode(WIFI_AP);
  
  // Setup Access Point
  WiFi.softAPConfig(apIP, gateway, subnet);
  WiFi.softAP(ap_ssid, ap_password);

  // ===========================
  // START SERVERS
  // ===========================
  Serial.println("[STEP 4] Starting Audio/Video Servers...");
  startCameraServer();
  audio_http_stream();
  VideoAudio_http();

  Serial.println("\n===================================");
  Serial.println("[ALL SYSTEMS GO]");
  Serial.println("===================================");
  Serial.println("1. Connect your phone/PC to this WiFi network:");
  Serial.print("   Network Name: ");
  Serial.println(ap_ssid);
  Serial.print("   Password:     ");
  Serial.println(ap_password);
  Serial.println();
  Serial.println("2. Copy and paste this exact link into your browser:");
  Serial.print("   http://");
  Serial.print(WiFi.softAPIP());
  Serial.println(":86");
  Serial.println("===================================\n");

  // Turn off the blinding flash LED now that setup is complete
  digitalWrite(FLASH_LED, LOW);
}

void loop() {
  // 1. Keep the custom audio and video servers running
  Audioserver.handleClient();
  VideoAudioserver.handleClient();

  // 2. Handle the PIR Motion Sensor
  bool pirState = (digitalRead(PIR_PIN) == HIGH);

  if (pirState) {
    // Only trigger ONCE when motion starts
    if (!motionDetected) {
      motionDetected = true;
      Serial.println(">>> MOTION DETECTED! <<<");

      // Flash the bright LED briefly as a visual alert
      digitalWrite(FLASH_LED, HIGH);
      delay(150);
      digitalWrite(FLASH_LED, LOW);
    }
  } else {
    // Area is clear — reset so next detection fires immediately
    motionDetected = false;
  }
}
